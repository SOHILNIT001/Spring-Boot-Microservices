package com.eg1;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.AfterClass;

import org.junit.Before;
import org.junit.BeforeClass;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.Assert;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

// @RunWith attaches a runner with the test class to initialize the test data
@RunWith(MockitoJUnitRunner.class)
public class FirstJUnitEg {

	static ArithBusinessLogic obj;
	static IArithService ias;

	// execute before class
	@BeforeClass
	public static void beforeClass() {
		System.out.println("in before class");

		obj = new ArithBusinessLogic();
		ias = mock(IArithService.class);

		obj.setIAService(ias);
	}

	// execute after class
	@AfterClass
	public static void afterClass() {
		System.out.println("in after class");
	}

	// execute before test
	@Before
	public void before() {
		System.out.println("in before");

	}

	// execute after test
	@After
	public void after() {
		System.out.println("in after");
	}

	// test case
	@Test
	public void test1() {

		// add the behavior to add numbers
		when(ias.iadd(20, 10)).thenReturn(30);
		// thenThrow()

		Assert.assertEquals(obj.add(20, 10), 30);

		System.out.println("in test1");

	}

	// test case
	@Test
	public void test2() {
		// subtract the behavior to subtract numbers
		when(ias.isub(20, 10)).thenReturn(10);

		Assert.assertEquals(obj.sub(20, 10), 10);
		System.out.println("in test2");
	}
	
	@Test
	public void avgTest1() {
		final double DELTA = 1e-15;
		float []arr = {23.2f,34.3f,54.1f,55.3f,72.4f};
		double vla = 0d;
		for(float v : arr) {
			vla += v;
		}
		double avgRes = vla/arr.length;
		when(ias.iAvg(vla, arr.length)).thenReturn(avgRes);
		
		Assert.assertEquals(obj.avg(vla, arr.length), avgRes,DELTA);
		System.out.println("in avgTest1");
	}
	
	@Test
	public void avgTest2() {
		final double DELTA = 1e-15;
		float []arr = {23.4f,66.6f,54.1f,35.1f,49.1f,11.3f,67.3f};
		double vla = 0d;
		for(float v : arr) {
			vla += v;
		}
		double avgRes = vla/arr.length;
		when(ias.iAvg(vla, arr.length)).thenReturn(avgRes);
		
		Assert.assertEquals(obj.avg(vla, arr.length), avgRes,DELTA);
		System.out.println("in avgTest2");
	}
	
	
	// test case ignore and will not execute
	@Ignore
	public void ignoreTest() {
		System.out.println("in ignore test");
	}
}