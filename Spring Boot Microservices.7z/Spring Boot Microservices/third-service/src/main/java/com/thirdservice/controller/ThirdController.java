package com.thirdservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mine")
public class ThirdController {
	
	@GetMapping("/msg")
	public String test() {
		return "Hello thirdservice in use called in ThirdService()";
	}
}
